﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Exceptions
{
    public class ExcpetionMessages
    {
        public const string FoodNotEatenException = "{0} does not eat {1}!";
    }
}
