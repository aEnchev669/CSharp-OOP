﻿

namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
