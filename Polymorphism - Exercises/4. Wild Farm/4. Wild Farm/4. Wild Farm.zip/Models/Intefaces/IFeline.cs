﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Intefaces
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
