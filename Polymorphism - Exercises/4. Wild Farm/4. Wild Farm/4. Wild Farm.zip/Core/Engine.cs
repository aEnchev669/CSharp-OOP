﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Core.Interfaces;
using WildFarm.Exceptions;
using WildFarm.Factories.Interfaces;
using WildFarm.IO.Inteface;
using WildFarm.Models.Intefaces;

namespace WildFarm.Core
{
    public class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;

        private readonly IAnimalFactory animalFactory;
        private readonly IFoodFactory foodFactory;

        private readonly ICollection<IAnimal> animals;

        private Engine() 
        {
            this.animals = new HashSet<IAnimal>();
        }

        public Engine(IReader reader, IWriter writer, IFoodFactory foodFactory, IAnimalFactory animalFactory) : this()
        {
            this.reader = reader;
            this.writer = writer;

            this.foodFactory = foodFactory;
            this.animalFactory = animalFactory;
        }

        public void Run()
        {
            string cmd = reader.ReadLine();

            while (cmd != "End")
            {
                this.ProcesInput(cmd);

                this.PrintAllAniamls();
                cmd = reader.ReadLine();
            }
        }

        public IAnimal BuildAnimalUsingFactory(string cmd)
        {
            string[] animalArgs = cmd.Split(" ", StringSplitOptions.RemoveEmptyEntries);

            IAnimal currAnimal = this.animalFactory.CreateAnimal(animalArgs);

            return currAnimal;
        }
        public IFood BuildFoodUsingFactory()
        {
            string[] foodArgs = reader.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string foodType = foodArgs[0];
            int foodQuantity = int.Parse(foodArgs[1]);

            IFood currFood = this.foodFactory.CreateFood(foodType, foodQuantity);

            return currFood;
        }
        private void ProcesInput(string cmd)
        {
            try
            {

                IAnimal currAnimal = this.BuildAnimalUsingFactory(cmd);
                IFood currFood = this.BuildFoodUsingFactory();
                this.writer.WriteLine(currAnimal.ProduceSound());
                currAnimal.Eat(currFood);

                this.animals.Add(currAnimal);

            }
            catch (InvalidAnimalTypeException iate)
            {

                this.writer.WriteLine(iate.Message);
            }
            catch (InvalidFoodTypeException ifty)
            {
                this.writer.WriteLine(ifty.Message);
            }
            catch (FoodNotEatenException fnee)
            {
                this.writer.WriteLine(fnee.Message);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void PrintAllAniamls()
        {
            foreach (IAnimal animal in animals)
            {
                this.writer.WriteLine(animal);
            }
        }
    }
}
