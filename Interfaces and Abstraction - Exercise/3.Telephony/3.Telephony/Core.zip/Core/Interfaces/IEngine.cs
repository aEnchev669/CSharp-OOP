﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Core.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
