﻿namespace Vehicles.Core.Intefaces
{
    public interface IEngine
    {
        public void Run();
    }
}