﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Exceptions
{
    public class ExceptionMessages
    {
        public const string FuelExceptionMessage = "{0} needs refueling";
    }
}
