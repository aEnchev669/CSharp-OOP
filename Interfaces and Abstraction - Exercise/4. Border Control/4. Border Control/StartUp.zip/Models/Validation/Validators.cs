﻿

namespace BorderControl.Models.Validation
{
    public interface Validators
    {
        public void ValidateId(string fakeId);
    }
}
