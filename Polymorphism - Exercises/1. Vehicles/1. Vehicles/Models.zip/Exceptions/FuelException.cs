﻿

namespace Vehicles.Exception
{
    using System;
    public class FuelException : Exception
    {
        

        public FuelException(string message) : base(message)
        {

        }
    }
}
