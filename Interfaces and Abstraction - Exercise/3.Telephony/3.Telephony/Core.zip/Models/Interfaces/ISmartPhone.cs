﻿

namespace Telephony.Models.Interfaces
{
    public interface ISmartPhone : IStationaryPhone
    {
        string BrowsingURL (string url);
    }
}
