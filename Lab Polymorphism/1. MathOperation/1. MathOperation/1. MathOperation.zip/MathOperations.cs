﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Operations
{
    public class MathOperations
    {
        public int Add(int i1, int i2)
        {
            return i1+ i2;
        }
        public double Add(double d1, double d2, double d3)
        {
            return d1 + d2 + d3;
        }
        public decimal Add(decimal d1, decimal d2, decimal d3)
        {
            return d1 + d2 + d3;
        }
    }
}
